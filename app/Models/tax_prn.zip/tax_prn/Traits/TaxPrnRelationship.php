<?php

namespace App\Models\tax_prn\Traits;

trait TaxPrnRelationship
{
    // 
}
